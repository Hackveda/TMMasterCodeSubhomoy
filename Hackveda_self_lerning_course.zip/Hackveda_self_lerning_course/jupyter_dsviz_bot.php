<?php
session_start();
//$_SESSION["username"] = $_GET["username"];
//$_SESSION["studentname"] = $_GET["studentname"];
//$_SESSION["topic"] = $_GET["topic"];
//$_SESSION["course"] = $_GET["course"];
//$_SESSION["path"] = $_GET["path"];
//$_SESSION["lesson"] = $_GET["lesson"];

function generateRandomString($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

$userno = generateRandomString(5); 
$username = $_GET["username"].$userno;
$username1 = $_GET["username"];
$studentname = $_GET["studentname"];
$topic = $_GET["topic"];
$course = $_GET["course"];
$lesson = $_GET["path"]."/".$_GET["lesson"];

?>

<html>
<head>
<title>
<?php echo $username1." - ".$topic." - ".$course; ?> | Hackveda    
</title>  
<link href="https://cdn.botframework.com/botframework-webchat/latest/botchat.css" rel="stylesheet" />
<style>
.flex-container {
    display: flex;
}

.flex-child {
    flex: 10;
    border: 0px solid black;
}  

.flex-child:first-child {
    margin-right: 10px;
}   
    
.flex-child-left {
    flex: 10;
    border: 0px solid black;
    width: 30%;
    border-radius: 15px;
}  

.flex-child-left:first-child {
    margin-right: 10px;
}  
    
.flex-child-right {
    flex: 10;
    border: 0px solid black;
    width: 70%;
    border-radius: 15px;
}  
    
.float-child.green {
    margin-right: 20px;
}
    
.float-container {
    padding: 0 px;
}

.float-child {
    width: 100%;
    height: 50%;
    float: left;
    padding: 0 px;
}  
    
    
.float-child-70 {
    width: 100%;
    height: 50%;
    float: left;
    padding: 0 px;
}  
   
.float-child-30 {
    width: 100%;
    height: 50%;
    float: left;
    padding: 0 px;
} 
    
.rounded{
    border-radius: 5px;
        
}
    
</style>
<body style="background-color: darkseagreen">

<div class="flex-container" style="background-color: darkseagreen; height: 100%;">

<div class="flex-child-left">

    
<iframe id="frame3" src="http://13.126.106.156:8889" frameborder="0" scrolling="no" width="100%" height="98.5%"  align="right" class="rounded">
</iframe>
    
<!-- <iframe id="frame3" src="https://www.devanshushukla.in:8889/?token=e5533da1c0c2b7f11c6a7eea38ce94bdca7a51e380bdf6ba" frameborder="0" scrolling="no" width="100%" height="99%"  align="right" class="rounded">
</iframe> --> 
    
<!--
<iframe id="frame3" src="http://13.126.106.156:8889/notebooks/Untitled1.ipynb?kernel_name=python3" frameborder="0" scrolling="no" width="100%" height="99%"  align="right" class="rounded">
</iframe>-->
    
</div>

<div class="flex-child-right"> 

<div class="float-container">
<div class="float-child-70 green">
    <iframe id="frame3" src="http://www.devanshushukla.in/dsviz/" frameborder="0" scrolling="no" width="100%" height="97%"  align="right" class="rounded">
</iframe>
</div>

<div class="float-child-30 green">
<iframe id="frame2" src="https://directline.botframework.com/embed/FirstBotHackveda?s=8ab0rYkZqjQ.zbDnLnqYM6CUL_VMLARXZbdyKShK4--Ub41PO3iyUxA&userID=<?php echo $username; ?>&username=<?php echo $lesson; ?>" frameborder="0" scrolling="no" width="100%" height="97%" align="right" class="rounded"></iframe>
</div>
  
</div>
</div>
    
</div>
    
</body>
</head>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/58e08d0bf7bbaa72709c3b48/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<script>
(function () {
        var options = {
            facebook: "209885845726743", // Facebook page ID
            whatsapp: "9654825370", // WhatsApp number
            call_to_action: "Sales", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "facebook,whatsapp", // Order of buttons
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })(); 
    </script>
</html>