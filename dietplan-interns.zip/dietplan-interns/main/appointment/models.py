from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Appointment(models.Model):
    
    first_name = models.CharField(max_length=55,blank=False, null=False)
    last_name = models.CharField(max_length=55, blank=False, null=False)
    email = models.EmailField(max_length=254,blank=False, null=False)
    phone_number = models.IntegerField(max_length=20,blank=True, null=True) # mobile
    relation_choice = (
        ('married', 'Married'),
        ('unmarried', 'Unmarried')
    )
    relation = models.CharField(choices=relation_choice,max_length=10,blank=False, null=False)
    consultation  = (
        ('PERSON IN A CLINIC',' person in a clinic'),
        ( 'phone or video','Remotely via telehealth'),
        ('PERSON AT YOUR HOME','In person, at your home')
    )
    consultationtype = models.CharField(choices=consultation,max_length=40,blank=True, null=True)
    available_slots = (
        ('9AM to 11AM', '9AM to 11AM'),
        ('12AM to 3PM', '12AM to 3PM'),
        ('4PM to 8PM', '4PM to 8PM')
    )
    availableslots = models.CharField(choices=available_slots,max_length=40,blank=True, null=True)
    session_charges= (
        ('1','Consultation Fee - Rs 1200 per visit'),
        ('2', 'Counselling Fee - Rs 3000 per session (45 minutes to 50minutes)'),
        ('3', 'Home visit Fee - Rs 7000 ')
    )
    sessioncharges = models.CharField(choices=session_charges,max_length=40,blank=True, null=True)
    approve = models.BooleanField(blank=True, null=True)
    booking = models.BooleanField(blank=True, null=True)

class UserProfile(models.Model):
    Roles = (
    ('user', 'User'),
    ('admin', 'Admin'),
    )
    user = models.OneToOneField(User,on_delete=models.CASCADE,default=None, null=True)
    role = models.CharField(max_length=50, choices=Roles)

    def __str__(self):
        return self.user.username