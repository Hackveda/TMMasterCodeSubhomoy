from django.urls import path
from .views import *

urlpatterns = [
    path('home/',home, name = 'home'),
    path('', AppointmentCreateView.as_view(), name='appointment-add'),
    path('admin_profile/', AdminProfileView.as_view(), name='admin-profile'),
    path('appointment_approve/<int:pk>', AppointmentApproveView.as_view(), name='appointment-approve'),
    path('appointment_booking/<int:pk>', AppointmentBookingView.as_view(), name='appointment-booking'),
    path('user_details/<int:pk>', UserProfileView.as_view(), name='user-details'),
    path('login/',login1,name='login'),
    path('admindelete/<int:pk>',AdminProfileDeleteView.as_view(),name='admindelete'),
    path('appointuser/<int:pk>',AppointProfileView.as_view(),name='appointuser'),
    path('logout/',logout_view,name='logout'),
    path('sendmail/<int:pk>',sendmail.as_view(),name='sendmail'),
]
    