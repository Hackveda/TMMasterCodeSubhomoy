from django.core.mail.message import EmailMessage
from django.http.response import HttpResponseBase, HttpResponseNotFound
from django.shortcuts import render, reverse , redirect
from django.http import HttpResponse
import requests
from dietplan.models import *
from .models import *
from .forms import *
from django.views.generic.edit import DeleteView
from django.contrib.messages.views import SuccessMessageMixin
from django.views import View
from django.views.generic.edit import ModelFormMixin, UpdateView, CreateView, DeleteView
from django.contrib import messages, auth
from django.contrib.auth.base_user import BaseUserManager
from django.core.mail import EmailMessage
from django.core.mail import send_mail
from django.conf import settings 
from django.template.loader import render_to_string
from django.contrib.auth import logout



# Create your views here.
def home(requests):
    template_name = 'patient/test.html'
    obj = Patient.objects.values()
    print(obj)
    # return redirect('all-patient')
    return redirect(reverse('patient-profile', kwargs={'pk':1}))
 

class AppointmentCreateView(View):
    #model = Appointment
    template_name = 'appointment/appointment_create_view.html'
   

    def get(self,request):
        form = AppointmentForm()
        context = {
            'form':form,
        }
        return render(request,self.template_name,context=context)
    def post(self,request):
        #patient = Patient.objects.get(pk=pk)
        length = 0
        for i in Appointment.objects.all():
            print("#####"+str(i.id))
            length = i.id
        length += 1
        print(length)
        form = AppointmentForm(request.POST)
        #print(form)
        if form.is_valid():
          
          firstname = form.cleaned_data['first_name']
          lastname = form.cleaned_data['last_name']
          email = form.cleaned_data['email']
          phoneno = form.cleaned_data['phone_number']
          relation = form.cleaned_data['relation']
          consultion = form.cleaned_data['consultationtype']
          availableslots =form.cleaned_data['availableslots']
          sessioncharges= form.cleaned_data['sessioncharges']
          form.save()
          template = render_to_string('appointment/email_template.html',{'first_name':firstname})  
          email = EmailMessage(
              'Thanks For Fixing Appointment',
              template,
              settings.EMAIL_HOST_USER,
              [email],
          )
          email.send()
          print(settings.EMAIL_HOST_USER)
          print(email)
          
        return HttpResponse("<h1>Thanks for submitting</h1>")

def login1(request):
    if request.method=="POST":
        username = request.POST['username']
        password = request.POST['pass']
        user = auth.authenticate(username=username,password=password)
        print(user)

        if user is not None and user.is_active:
            if user.userprofile.role == 'user':
                t_id = user.id
                print(t_id)
                t_name = user.username
                print(t_name)
                user_obj = User.objects.get(id = t_id)
                print(user_obj.first_name)
                appoint_obj = Appointment.objects.get(first_name = user_obj.first_name , email = user_obj.email)
                print(appoint_obj.id)
                return redirect(reverse('appointuser', kwargs = {'pk':appoint_obj.id}))
            elif user.userprofile.role == 'admin':
                s_id = user.id
                print(s_id)
                return redirect('admin-profile')

        else:
            messages.info(request,"invalid login")
            return redirect('login')

    else:
        return render(request, "appointment/login.html")


def logout_view(request):
    logout(request)
    return redirect('login')

class AdminProfileView(View):

    template_name = 'appointment/admin_profile_view.html'

    def get(self, request):
        # patient = Patient.objects.get(id=pk)
        appointment_details = Appointment.objects.all()
        print(appointment_details)

        context={
            'appointment_details' : appointment_details,
            }
        return render(request, self.template_name, context )

class AdminProfileDeleteView(DeleteView):
    # login_url = '/login/'
    model = Appointment
    template_name = 'appointment/delete_adminprofile.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('admin-profile')        

class AppointmentApproveView(View):
    # login_url = '/login/'

    template_name = 'appointment/appointment_approve_view.html'

    def get(self, request,pk = None):
        return render(request, self.template_name)
    
    def post(self,request,pk = None):

        password = BaseUserManager().make_random_password()
        print(pk)
        appoint = Appointment.objects.get(id=pk)
        print(appoint.approve)

        user = User.objects.get_or_create(username=appoint.email,email=appoint.email,first_name=appoint.first_name,last_name=appoint.last_name)
        print(user)
        if user[1] :
            print(password)
            #user[0].username = appoint.email
            user[0].set_password(password)
            user[0].save()
            template = render_to_string('appointment/email_password.html',{'first_name':appoint.first_name,'username':appoint.email,'password':password})  
            email = EmailMessage(
              'username and password..!',
              template,
              settings.EMAIL_HOST_USER,
              [appoint.email],
            )
            email.send()
        user = user[0]
        print(user)
        user_profile = UserProfile.objects.get_or_create(user = user,role = 'user')
        print(user_profile[0].user.first_name)
        import datetime
        x = datetime.datetime.now()
        print(x)
        print(appoint.first_name,appoint.last_name)
        patient_bool = Patient.objects.filter(first_name=appoint.first_name.title(),email=appoint.email,last_name=appoint.last_name.title()).exists()
        print(patient_bool)
        if not patient_bool:
            patient = Patient.objects.create(first_name = appoint.first_name.title(),last_name = appoint.last_name.title(),phone_number=appoint.phone_number,email = appoint.email,dob = x)
            print(patient)
        if appoint.approve == False or appoint.approve is None:
            appoint.approve = True
            appoint.save()

        return redirect('admin-profile')
        # return redirect(reverse('patient-profile', kwargs = {'pk': dietplan[0].id}))

class UserProfileView(View):
    # login_url = '/login/'
    
    template_name = 'appointment/user_profile_view.html'

    def get(self, request,pk = None):

        user_details = Appointment.objects.filter(id=pk).all()
        print(user_details)
        user_details1 = Appointment.objects.get(id=pk)
        dietplan_id = Patient.objects.get(first_name=user_details1.first_name.title(),email=user_details1.email,last_name=user_details1.last_name.title())
        print(dietplan_id.id)
        context={
            'user_details' : user_details,
            'dietplan_id' : dietplan_id,
            }
        return render(request, self.template_name, context)

class AppointProfileView(View):
    # login_url = '/login/'
    template_name = 'appointment/appointuser.html'

    def get(self, request,pk = None):

        user_details = Appointment.objects.filter(id=pk).all()
        print(user_details)
        user_details1 = Appointment.objects.get(id=pk)
        dietplan_id = Patient.objects.get(first_name=user_details1.first_name.title(),email=user_details1.email,last_name=user_details1.last_name.title())
        print(dietplan_id.id)
        context={
            'appoint_user' : user_details,
            'dietplan_id' : dietplan_id,
            }
        return render(request, self.template_name, context)

class AppointmentBookingView(View):
    # login_url = '/login/'

    template_name = 'appointment/appointment_booking_view.html'

    def get(self, request,pk = None):
        return render(request, self.template_name)
    
    def post(self,request,pk = None):

        appoint = Appointment.objects.get(id=pk)
        print(appoint.booking)
        if appoint.booking == False or appoint.booking is None:
            appoint.booking = True
            appoint.save()

        return redirect('admin-profile')

class sendmail(View):
    template_name = 'appointment/sendmail.html'
    def get(self, request,pk = None):
        print('@@@'+str(pk))
        appoint = Appointment.objects.filter(id=pk).values()
        print('***********'+str(appoint))
        email = request.POST.get('email')
        print('^^^^^^^^'+str(email))
        email1 = appoint[0]['email']
        print('%%%%%%%%%'+str(email1))
        return render(request, self.template_name,{'email':email1})
        
    def post(self,request,pk = None):
        if request.method== "POST":
            subject=request.POST.get('subject')
            print(subject)
            message=request.POST.get('message')
            print(message)
            appoint = Appointment.objects.filter(id=pk).values()
            print('***********'+str(appoint))
            email2 = request.POST.get('email')
            print('^^^^^^^^'+str(email2))
            email1 = appoint[0]['email']
            print('%%%%%%%%%'+str(email1))
            send_mail(
                subject,
                 message,
                settings.EMAIL_HOST_USER,
                [email1],
            )
        
        return  redirect('admin-profile')

      
        
           
    
            
