from django.contrib import admin
from .models import *


# Register your models here.
admin.site.register(Like)
admin.site.register(Dislike)
admin.site.register(Fasting)
admin.site.register(Name)
admin.site.register(Document)
admin.site.register(Patient)
admin.site.register(Disease)
admin.site.register(FamilyHistory)
admin.site.register(PersonalityAnswers)
admin.site.register(PersonalityQuestion)
admin.site.register(FatScan)
admin.site.register(WaterIntake)
admin.site.register(FoodTiming)
admin.site.register(FoodDiary)
admin.site.register(SymptomCategory)
admin.site.register(Symptom)
admin.site.register(PatientSymptom)
admin.site.register(MedicalConditionsCategory)
admin.site.register(MedicalConditions)
admin.site.register(PatientMedicalConditions)
admin.site.register(DrinksType)
admin.site.register(Alcohol)
admin.site.register(MenstrualCycle)
admin.site.register(BloodPressure)
admin.site.register(StoolType)
admin.site.register(Stool)
admin.site.register(StoolColourType)
admin.site.register(StoolColour)
admin.site.register(StoolClearance)
admin.site.register(Cusine)
admin.site.register(BodyMeasurement)



@admin.register(CategoryName)
class CategoryNameAdmin(admin.ModelAdmin):
    list_display = ( 'category_name', 'sub_category_name','product_name')
    list_filter = ('category_name','sub_category_name','product_name')
    search_fields = ['category_name','sub_category_name','product_name']
    pass

@admin.register(Issues)
class IssuesAdmin(admin.ModelAdmin):
    list_display = ( 'patient', 'issues')
    list_filter = ( 'patient', 'issues')
    search_fields = ['patient__first_name']
    pass

@admin.register(MedicalHistory)
class MedicalHistoryAdmin(admin.ModelAdmin):
    list_display = ( 'patient', 'medical_issues','date_of_start')
    list_filter = ( 'patient', 'medical_issues','date_of_start')
    search_fields = ['patient__first_name','medical_issues']
    pass

@admin.register(MedicationList)
class MedicationListAdmin(admin.ModelAdmin):
    list_display = ( 'patient', 'medication','startdate')
    list_filter = ( 'patient', 'medication','startdate')
    search_fields = ['patient__first_name','medication']
    pass
