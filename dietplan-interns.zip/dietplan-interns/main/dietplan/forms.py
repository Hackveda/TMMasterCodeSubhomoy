from django import forms
from django.forms import fields
from .models import *
# from jsonfield.fields import JSONFormField

class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ('description', 'document', )

class IssuesForm(forms.ModelForm):
    class Meta:
        model = Issues
        fields = ('issues',)

class MedicalHistoryForm(forms.ModelForm):
    class Meta:
        model = MedicalHistory
        fields = ('medical_issues','date_of_start',)

class MedicationListForm(forms.ModelForm):
    class Meta:
        model = MedicationList
        fields = ('medication','dosage','startdate','reason',)

class FatScanForm(forms.ModelForm):
    class Meta:
        model = FatScan
        fields = ('weight','total_fat','visceral_fat','kcal','bmi','age','total_sc_bf','sc_trunk','sc_arms','skeletal_wb','sk_trunk','sk_arms','sk_legs','iw',)

class WaterIntakeForm(forms.ModelForm):
    class Meta:
        model = WaterIntake
        fields = ('litres','time',)

class FoodDiaryForm(forms.ModelForm):
    class Meta:
        model = FoodDiary
        fields = ('timing','time','food',)

class BloodPressureForm(forms.ModelForm):
    class Meta:
        model = BloodPressure
        fields = ('systolic','diastolic','pulse',)

class MenstrualCycleForm(forms.ModelForm):
    class Meta:
        model = MenstrualCycle
        fields = ('pms','bleeding','regularity',)

class AlcoholForm(forms.ModelForm):
    class Meta:
        model = Alcohol
        fields = ('times','drinks','drink_type','cigerette','cigerette_number','hukka','drugs',)

class StoolClearanceForm(forms.ModelForm):
    class Meta:
        model = StoolClearance
        fields = ('stool_passing','stool_clearance','clearance_grade','frequency',)
    
class FastingForm(forms.ModelForm):
    class Meta:
        model = Fasting
        fields =  (
                    'like','Savory','Sweet','spice','fasting','Days_of_fasting',
                    'Month_of_fasting','Occasion_of_fasting','details_of_fasting',
                    'desciption_of_fasting',
                    )

class LikeForm(forms.ModelForm):
    class Meta:
        model = Like
        fields = ('Like',
                    )

class DislikeForm(forms.ModelForm):
     class Meta:
        model = Dislike
        fields = (
                    'DisLike',
                    )

class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = ('__all__')
class CusineForm(forms.ModelForm):
    class Meta:
        model = Cusine
        fields = ('category', 'item', )

class BodyMeasurementForm(forms.ModelForm):
    class Meta:
        model = BodyMeasurement
        fields = ('neck','shoulder','chest','waist','pelvis','hip','thigh','calf','arm','wrist','shape','ratio','ideal_waist')
