from colorfield.fields import ColorField
from django.db import models
import os
import uuid
import random
from jsonfield import JSONField

from datetime import datetime
from multiselectfield import MultiSelectField

def user_directory_path(instance, filename):
    # Get Current Date
    todays_date = datetime.now()
    current_time = todays_date.strftime("%H:%M:%S")
    path = "documents/"
    # extension = "." + filename.split('.')[-1]
    extension = str(filename[:-4])+ '--' + str(current_time)
    # stringId = str(uuid.uuid4())
    # randInt = str(random.randint(10, 99))

    # Filename reformat
    filename_reformat = extension

    return os.path.join(path, filename_reformat)


# Create your models here.
class Name(models.Model):
    name = models.CharField(max_length=55,blank=False,null=False,unique=True)

    def __str__(self) -> str:
        return f"{self.name}"

    def __repr__(self) -> str:
        return f"{self.name}"

    def save(self, *args, **kwargs):
        self.name=self.name.upper()
        super(Name, self).save(*args, **kwargs)

class CategoryName(models.Model):
    category_name = models.CharField(max_length=255,blank=False,null=False)
    sub_category_name = models.CharField(max_length=255,blank=False,null=False)
    product_name =  models.CharField(max_length=255,blank=False,null=False)
    ingredients =  models.TextField(blank=False,null=False)
    instructions =  models.TextField(blank=False,null=False)

    def __str__(self) -> str:
        return f"{self.sub_category_name}"

    def __repr__(self) -> str:
        return f"{self.sub_category_name}"

    def save(self, *args, **kwargs):
        self.sub_category_name=self.sub_category_name.upper()
        super(CategoryName, self).save(*args, **kwargs)

class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to=user_directory_path)
    uploaded_at = models.DateTimeField(auto_now_add=True)


class Patient(models.Model):
    first_name = models.CharField(max_length=55, blank=False, null=False)
    last_name = models.CharField(max_length=55, blank=False, null=False)
    age = models.IntegerField(blank=True,null = True)
    height = models.FloatField(max_length=55, blank=True, null=True)
    weight = models.FloatField(max_length=55,blank = True,null = True)
    email = models.EmailField(max_length=254, blank=False, null=False, unique=False)

    gender_choice = (
        ('male', 'Male'),
        ('female', 'Female')
    )

    sex = models.CharField(choices=gender_choice, max_length=10)
    address = models.TextField(max_length=255, blank=True, null=True)
    postal_zip = models.IntegerField( blank=True, null=True)
    city = models.CharField(max_length=255, blank=True, null=True)
    country = models.CharField(max_length=255, blank=True, null=True)
    phone_number = models.IntegerField(blank=True, null=True) # mobile
    alternate_number = models.IntegerField(blank=True, null=True) # alternate
    dob = models.DateField(auto_now_add=False)
    profession = models.CharField(max_length=255, blank=True, null=True)
    bloodtest_choice = (
        ('yes','YES'),
        ('no','NO')
    )
    bloodtest = models.CharField(choices=bloodtest_choice, max_length=5)

    def save(self, *args, **kwargs):
        self.first_name = self.first_name.title()
        self.last_name = self.last_name.title()
        super(Patient, self).save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.first_name} {self.last_name}"

    def __repr__(self) -> str:
        return f"{self.first_name} {self.last_name}"

class Issues(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    issues = models.TextField(blank=False,null=False)

    def __str__(self) -> str:
        return f"{self.issues}"

    def __repr__(self) -> str:
        return f"{self.issues}"

    def save(self, *args, **kwargs):
        super(Issues, self).save(*args, **kwargs)

class MedicalHistory(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    medical_issues = models.TextField(blank=False,null=False)
    date_of_start = models.DateField(auto_now_add=False)

    def __str__(self) -> str:
        return f"{self.medical_issues}"

    def __repr__(self) -> str:
        return f"{self.medical_issues}"

    def save(self, *args, **kwargs):
        super(MedicalHistory, self).save(*args, **kwargs)

class MedicationList(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    medication = models.CharField(max_length=255,blank=False,null=False)
    dosage = models.TextField(blank=False,null=False)
    startdate = models.DateField(auto_now_add=False)
    reason = models.TextField(blank=False,null=False)

    def __str__(self) -> str:
        return f"{self.medication}"

    def __repr__(self) -> str:
        return f"{self.medication}"

    def save(self, *args, **kwargs):
        super(MedicationList, self).save(*args, **kwargs)

class Disease(models.Model):
    name = models.CharField(max_length=50,unique=True,blank=False,null=False)

    def __str__(self) -> str:
        return f"{self.name}"

    def __repr__(self) -> str:
        return f"{self.name}"

    def save(self, *args, **kwargs):
        super(Disease, self).save(*args, **kwargs)


class FamilyHistory(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    disease = models.ForeignKey(to=Disease, on_delete=models.CASCADE, unique=False)
    side = models.CharField(max_length=20)

    def __str__(self) -> str:
        return f"{self.patient} {self.disease}"

    def __repr__(self) -> str:
        return f"{self.patient} {self.disease}"

    def save(self, *args, **kwargs):
        super(FamilyHistory, self).save(*args, **kwargs)

class PersonalityQuestion(models.Model):
    part_choices = (
        ('1', '1'),
        ('2', '2'),
        ('3', '3')
    )
    part = models.CharField(choices=part_choices,max_length=10)
    observation = models.CharField(max_length=200)
    option1 = models.CharField(max_length=200)
    option2 = models.CharField(max_length=200)
    option3 = models.CharField(max_length=200)


    def __str__(self) -> str:
        return f"part {self.part} - {self.observation}"

    def __repr__(self) -> str:
        return f"part {self.part} - {self.observation}"

    def save(self, *args, **kwargs):
        super(PersonalityQuestion, self).save(*args, **kwargs)

class PersonalityAnswers(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    question = models.ForeignKey(to=PersonalityQuestion, on_delete=models.CASCADE, unique=False)
    option1 = models.IntegerField(null=True)
    option2 = models.IntegerField(null=True)
    option3 = models.IntegerField(null=True)


    def __str__(self) -> str:
        return f"{self.patient} - {self.question}"

    def __repr__(self) -> str:
        return f"{self.patient} - {self.question}"

    def save(self, *args, **kwargs):
        super(PersonalityAnswers, self).save(*args, **kwargs)

class FatScan(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    weight = models.FloatField(max_length=55, blank=False, null=False)
    total_fat = models.FloatField(max_length=55, blank=False, null=False)
    visceral_fat = models.FloatField(max_length=55,blank = False,null = False)
    kcal = models.FloatField(max_length=55, blank=False, null=False)
    bmi = models.FloatField(max_length=55, blank=False, null=False)
    age = models.IntegerField(max_length=55,blank = False,null = False)
    total_sc_bf = models.FloatField(max_length=55, blank=False, null=False)
    sc_trunk = models.FloatField(max_length=55, blank=False, null=False)
    sc_arms = models.FloatField(max_length=55,blank = False,null = False)
    skeletal_wb = models.FloatField(max_length=55, blank=False, null=False)
    sk_trunk = models.FloatField(max_length=55, blank=False, null=False)
    sk_arms = models.FloatField(max_length=55,blank = False,null = False)
    sk_legs = models.FloatField(max_length=55, blank=False, null=False)
    iw = models.FloatField(max_length=55, blank=False, null=False)
    
    def save(self, *args, **kwargs):
        super(FatScan, self).save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"


class WaterIntake(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    litres = models.IntegerField(max_length=55,blank=False,null=False)
    time = models.TimeField(auto_now_add=False)

    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"

    def save(self, *args, **kwargs):
        super(WaterIntake, self).save(*args, **kwargs)

class FoodTiming(models.Model):
    name = models.CharField(max_length=50,unique=True,blank=False,null=False)

    def __str__(self) -> str:
        return f"{self.name}"

    def __repr__(self) -> str:
        return f"{self.name}"

    def save(self, *args, **kwargs):
        super(FoodTiming, self).save(*args, **kwargs)

class FoodDiary(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    timing = models.ForeignKey(to=FoodTiming, on_delete=models.CASCADE, unique=False)
    time = models.TimeField(auto_now_add=False)
    food = models.TextField(max_length=255)

    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"

    def save(self, *args, **kwargs):
        super(FoodDiary, self).save(*args, **kwargs)

class SymptomCategory(models.Model):
    category = models.CharField(max_length=200)

    def __str__(self) -> str:
        return f"{self.category}"

    def __repr__(self) -> str:
        return f"{self.category}"

    def save(self, *args, **kwargs):
        super(SymptomCategory, self).save(*args, **kwargs)

class Symptom(models.Model):
    part_choices = (
        ('a', 'A'),
        ('b', 'B'),
        ('c', 'C')
    )
    part = models.CharField(choices=part_choices,max_length=10)
    category = models.ForeignKey(to=SymptomCategory, on_delete=models.CASCADE, unique=False)
    symptom = models.CharField(max_length=200)


    def __str__(self) -> str:
        return f"{self.category},{self.symptom},{self.part}"

    def __repr__(self) -> str:
        return f"{self.category},{self.symptom},{self.part}"

    def save(self, *args, **kwargs):
        super(Symptom, self).save(*args, **kwargs)

class PatientSymptom(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    symptom = models.ForeignKey(to=Symptom, on_delete=models.CASCADE, unique=False)

    def __str__(self) -> str:
        return f" {self.patient} - {self.symptom}"

    def __repr__(self) -> str:
        return f" {self.patient} - {self.symptom}"

    def save(self, *args, **kwargs):
        super(PatientSymptom, self).save(*args, **kwargs)


class MedicalConditionsCategory(models.Model):
    category = models.CharField(max_length=200)

    def __str__(self) -> str:
        return f"{self.category}"

    def __repr__(self) -> str:
        return f"{self.category}"

    def save(self, *args, **kwargs):
        super(MedicalConditionsCategory, self).save(*args, **kwargs)

class MedicalConditions(models.Model):
    part_choices = (
        ('a', 'A'),
        ('b', 'B'),
        ('c', 'C')
    )
    part = models.CharField(choices=part_choices,max_length=10)
    category = models.ForeignKey(to=MedicalConditionsCategory, on_delete=models.CASCADE, unique=False)
    medical_condition = models.CharField(max_length=200)


    def __str__(self) -> str:
        return f"{self.category},{self.medical_condition},{self.part}"

    def __repr__(self) -> str:
        return f"{self.category},{self.medical_condition},{self.part}"

    def save(self, *args, **kwargs):
        super(MedicalConditions, self).save(*args, **kwargs)

class PatientMedicalConditions(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    medical_condition = models.ForeignKey(to=MedicalConditions, on_delete=models.CASCADE, unique=False)

    def __str__(self) -> str:
        return f" {self.patient} - {self.medical_condition}"

    def __repr__(self) -> str:
        return f" {self.patient} - {self.medical_condition}"

    def save(self, *args, **kwargs):
        super(PatientMedicalConditions, self).save(*args, **kwargs)

class DrinksType(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self) -> str:
        return f"{self.name}"

    def __repr__(self) -> str:
        return f"{self.name}"

    def save(self, *args, **kwargs):
        super(DrinksType, self).save(*args, **kwargs)

class Alcohol(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    times_choices = (
        ('yes', 'Yes'),
        ('no', 'No')
    )
    times = models.CharField(choices=times_choices,max_length=10)
    drinks = models.IntegerField(max_length=50,blank=False, null=False)
    drink_type = models.ForeignKey(to=DrinksType, on_delete=models.CASCADE, unique=False)
    cigerette = models.CharField(choices=times_choices,max_length=10)
    cigerette_number = models.IntegerField(max_length=50,blank=False, null=False,default=0)
    hukka = models.CharField(choices=times_choices,max_length=10)
    drugs = models.CharField(choices=times_choices,max_length=10)


    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"

    def save(self, *args, **kwargs):
        super(Alcohol, self).save(*args, **kwargs)

class MenstrualCycle(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    times_choices = (
        ('yes', 'Yes'),
        ('no', 'No')
    )
    bleeding_choices = (
        ('light','Light'),
        ('ok','OK'),
        ('heavy','Heavy')
    )
    regularity_choices = (
        ('regular','Regular'),
        ('irregular','Irregular')
    )
    pms = models.CharField(choices=times_choices,max_length=10)
    bleeding = models.CharField(choices=bleeding_choices,max_length=10)
    regularity = models.CharField(choices=regularity_choices,max_length=10)


    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"

    def save(self, *args, **kwargs):
        super(MenstrualCycle, self).save(*args, **kwargs)

class BloodPressure(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    systolic = models.CharField(max_length=50,blank=False, null=False)
    diastolic = models.CharField(max_length=50,blank=False, null=False)
    pulse = models.CharField(max_length=50,blank=False, null=False)

    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"

    def save(self, *args, **kwargs):
        super(BloodPressure, self).save(*args, **kwargs)

class StoolType(models.Model):
    name = models.CharField(max_length=50,unique=True,blank=False,null=False)
    stool_image = models.ImageField(upload_to ='stool_images/')
    description = models.TextField(max_length=255, blank=True, null=True)

    def __str__(self) -> str:
        return f"{self.name}"

    def __repr__(self) -> str:
        return f"{self.name}"

    def save(self, *args, **kwargs):
        super(StoolType, self).save(*args, **kwargs)


class Stool(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    stool_type = models.ForeignKey(to=StoolType, on_delete=models.CASCADE, unique=False)

    def __str__(self) -> str:
        return f"{self.patient} {self.stool_type}"

    def __repr__(self) -> str:
        return f"{self.patient} {self.stool_type}"

    def save(self, *args, **kwargs):
        super(Stool, self).save(*args, **kwargs)

class StoolColourType(models.Model):
    type = models.CharField(max_length=50,unique=True,blank=False,null=False)
    stool_colour = ColorField(format='hexa')
    colour_name = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self) -> str:
        return f"{self.type}"

    def __repr__(self) -> str:
        return f"{self.type}"

    def save(self, *args, **kwargs):
        super(StoolColourType, self).save(*args, **kwargs)

class StoolColour(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    stool_colour = models.ForeignKey(to=StoolColourType, on_delete=models.CASCADE, unique=False)

    def __str__(self) -> str:
        return f"{self.patient} {self.stool_colour}"

    def __repr__(self) -> str:
        return f"{self.patient} {self.stool_colour}"

    def save(self, *args, **kwargs):
        super(StoolColour, self).save(*args, **kwargs)

class StoolClearance(models.Model):
    times_choices = (
        ('yes', 'Yes'),
        ('no', 'No')
    )
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    stool_passing = models.CharField(choices=times_choices,max_length=10)
    stool_clearance = models.CharField(choices=times_choices,max_length=10)
    clearance_grade = models.IntegerField(max_length=50, blank=True, null=True)
    frequency = models.IntegerField(max_length=50, blank=True, null=True)
class Cusine(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    category = models.CharField(max_length=100)
    item = models.CharField(max_length=200)

    def __str__(self) -> str:
        return f"{self.category} - {self.item}"

    def __repr__(self) -> str:
        return f"{self.category} - {self.item}"

    def save(self, *args, **kwargs):
        super(Cusine, self).save(*args, **kwargs)


class BodyMeasurement(models.Model):
    shapechoices=(
        ("Apple","Apple"),
        ("Pear","Pear")
    )
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE)
    height = models.CharField(max_length=50,blank=True)
    neck = models.CharField(max_length=50,blank=True)
    shoulder = models.CharField(max_length=50,blank=True)
    chest = models.CharField(max_length=50,blank=True)
    waist = models.CharField(max_length=50,blank=True)
    pelvis = models.CharField(max_length=50,blank=True)
    hip = models.CharField(max_length=50,blank=True)
    thigh = models.CharField(max_length=50,blank=True)
    calf = models.CharField(max_length=50,blank=True)
    arm = models.CharField(max_length=50,blank=True)
    wrist = models.CharField(max_length=50,blank=True)
    shape = models.CharField(choices=shapechoices,max_length=50,blank=True)
    ratio = models.CharField(max_length=50,blank=True)
    ideal_waist = models.CharField(max_length=50,blank=True)

    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"

    def save(self, *args, **kwargs):
        super(StoolClearance, self).save(*args, **kwargs)
    
class Fasting(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    part_choices = (
        ('veg', 'VEG'),
        ('nonveg', 'NONVEG'),
        ('Egg', 'EGG'),
    )
    like  = MultiSelectField(choices=part_choices)
    spice_choice = (
        ('mild','MILD'),
        ('medium','MEDIUM'),
        ('hot','HOT')
    )
    spice = models.CharField(choices=spice_choice,max_length=10)
    craving_choice = (
        ('7:00am-12:00pm','7:00am-12:00pm'),
        ('12:00pm-4:00pm','12:00pm-4:00pm'),
        ('4:00pm-8:00pm','4:00pm-8:00pm'),
        ('8:00pm-12:00am','8:00pm-12:00am')
    )
    Savory = MultiSelectField(choices=craving_choice)
    Sweet  = MultiSelectField(choices=craving_choice)
    fasting_choice = (
        ('yes','YES'),
        ('intermediate fasting','INTERMITTENT FASTING'),
        ('no','NO')
    )
    fasting = models.CharField(choices=fasting_choice,max_length=20)
    days_of_fasting_choice = (
        ('monday','MONDAY'),
        ('tuesday','TUESDAY'),
        ('wednesday','WEDNESDAY'),
        ('thursday','THURSDAY'),
        ('friday','FRIDAY'),
        ('saturday','SATURDAY'),
        ('sunday','SUNDAY')
        )
    Days_of_fasting  = MultiSelectField(choices=days_of_fasting_choice)
    monthly_choice = (
        ('ekadashi','EKADASHI'),
        ('puranmashi','PURANMASHI')
    )
    Month_of_fasting  = MultiSelectField(choices=monthly_choice)
    occasion_choice = (
        ('ramzan','RAMZAN'),
        ('navratra','NAVRATRA'),
        ('shrad','SHRAD'),
        ('paryushana','PARYUSHANA'),
        ('shivratri','SHIVRATRI'),
        ('karwachauth','KARWACHAUTH'),
        ('sankatchauth','SANKATCHAUTH')
    )
    Occasion_of_fasting  = MultiSelectField(choices=occasion_choice)
    details_of_fasting = models.TextField(max_length=1000)
    desciption_of_fasting = models.TextField(max_length=700)

    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"

class Like(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    Like = models.CharField(max_length=500,unique=False,blank=False,null=False)
    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"

class Dislike(models.Model):
    patient = models.ForeignKey(to=Patient, on_delete=models.CASCADE, unique=False)
    DisLike = models.CharField(max_length=50,unique=False,blank=False,null=False)

    def __str__(self) -> str:
        return f"{self.patient}"

    def __repr__(self) -> str:
        return f"{self.patient}"
        super(BodyMeasurement, self).save(*args, **kwargs)
