import os
import docx2txt
import json
import re
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render, redirect, reverse
from django.contrib.messages.views import SuccessMessageMixin
from django.views import View
from django.views.generic.edit import ModelFormMixin, UpdateView, CreateView, DeleteView
from django.views.generic.detail import DetailView
from django.http import JsonResponse
from django.views.generic.list import ListView


#import from models.py and forms.py
from .models import *
from .forms import *

from django.template.defaulttags import register

@register.filter
def get_item(dictionary, key):
    return dictionary.get(key)

def sample(request):
    return render (request,'dietplan/sample.html')

#Upload Document for Extraction
def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('category_name')
    else:
        form = DocumentForm()
    return render(request, 'dietplan/model_form_upload.html', {
        'form': form
    })

#Function to extract features from Uploaded Document
def category_name(request):


    # categories = os.listdir("dietplan//KOLKATTA-BENGALI FOLDER (English)")
    categories = os.listdir("media//documents")

    data = {}

    for category in categories:
        # my_text = docx2txt.process("dietplan//KOLKATTA-BENGALI FOLDER (English)//"+category)
        my_text = docx2txt.process("media//documents//"+category)
        data[category]={}
        sno= my_text.find("S.NO.")
        no =  my_text.find("NO.")
        endi = no if sno==-1 or sno>no else sno
        new_txt = my_text[my_text.find("INDEX"):endi]
        no_of_subcategories=1
        while new_txt.find(str(no_of_subcategories)+".")!=-1:
            no_of_subcategories+=1
        no_of_subcategories-=1
        i=1
        product_list=[]
        while i<=no_of_subcategories:
            sub_category_data = new_txt[new_txt.find(str(i)+"."):new_txt.find(str(i+1)+".")]
            # print(sub_category_data)
            sub_category_data = [ j.strip() for j in sub_category_data.replace("\t"," ").split("\n") if j.strip()!="" and len(j)>1]
            # print(sub_category_data)
            sub_category=sub_category_data[0][2:sub_category_data[0].rfind(" ")].strip()
            # print(sub_category)
            data[category][sub_category]={}
            for j in range(1,len(sub_category_data)):
                data[category][sub_category][sub_category_data[j][:sub_category_data[j].rfind(" ")].strip()]=[]
                product_list.append(sub_category_data[j][:sub_category_data[j].rfind(" ")].strip())

            i+=1
        product_list.append("last product name which could not be searched but is still here aasdadwdawdasawdadd")
        table_data = my_text[endi:]
        i=1
        df={"Category":[],"Subcategory":[],"Product":[],"Ingredients":[],"Instructions":[]}
        for sub_category in data[category]:
            for product in data[category][sub_category]:
                product_data=table_data[table_data.find(product):]
                product_data = product_data[:product_data.find(product_list[i])]
                product_data = product_data[product_data.find("Ingredients:"):]
                product_data=product_data.replace("Ingredients:","")
                product_data = product_data.split("Instructions:")
                data[category][sub_category][product]=product_data
                # print(category,sub_category,product)
                # print(product_data)
                try:
                    obj=CategoryName.objects.filter(category_name=category,sub_category_name=sub_category,product_name=product)[0]
                    obj.ingredients=product_data[0]
                    obj.instructions=product_data[1]
                    obj.save()
                except Exception as e:
                    obj=CategoryName.objects.create(category_name=category,sub_category_name=sub_category,product_name=product)
                    obj.ingredients=product_data[0]
                    obj.instructions=product_data[1]
                    obj.save()
                    print(e)
                df["Category"].append(category)
                df["Subcategory"].append(sub_category)
                df["Product"].append(product)
                df["Ingredients"].append(product_data[0])
                df["Instructions"].append(product_data[1])

                i+=1
        # df=pd.DataFrame(df)
        # print(my_text)

    return HttpResponse("<h1>TM Master Server</h1>")

# Create Patient
class PatientCreateView(SuccessMessageMixin, CreateView):
    model = Patient
    fields = '__all__'
    template_name = 'dietplan/patient_create_view.html'
    success_message = "Patient was added successfully"

    def get_success_url(self):
        return reverse('patient-profile', kwargs = {'pk': self.object.id})

class PatientUpdateView(View):
    
    template_name = 'dietplan/patient_update.html'
    #fields = '_all_'

    def get(self,request,pk):
        patient =Patient.objects.filter(id=pk)[0]
        print(patient)
        form = PatientForm(request.GET or None,instance=patient)
        context = {
            'form':form,
            'patient':patient, 
        }

        return render(request,self.template_name,context=context) 

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = PatientForm(request.POST or None, instance=patient)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id})) 


class PatientListView(ListView):
    model = Patient
    template_name = 'dietplan/patient_all.html'
    context_object_name = 'patient_list'

class PatientDeleteView(DeleteView):
    model = Patient
    template_name = 'dietplan/delete_patient.html'
    fields = ('_all_')

    def get_success_url(self):
        return reverse('all-patient')
# Create Issues
class IssuesCreateView(CreateView):
    template_name = 'dietplan/patient_issues_create.html'

    def get(self, request, pk = None ):
        form = IssuesForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = IssuesForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class IssuesUpdateView(View):
    template_name = 'dietplan/patient_issues_update.html'

    def get(self, request, pk = None ):
        issues = Issues.objects.get(id=pk)
        print(issues,pk)
        form = IssuesForm(request.GET or None,instance=issues)
        print(form)
        try:
            issues = Issues.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'issues' : issues
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        issues = Issues.objects.get(pk = pk)
        form = IssuesForm(request.POST or None, instance=issues)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': issues.patient.id}))

class IssuesDeleteView(DeleteView):
    model = Issues
    template_name = 'dietplan/delete_Issues.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})

# Create Medical History
class MedicalHistoryCreateView(CreateView):
    template_name = 'dietplan/patient_medical_history.html'

    def get(self, request, pk = None ):
        form = MedicalHistoryForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        form = MedicalHistoryForm(request.POST , request.FILES)
        print(request.POST)
        patient = Patient.objects.get(pk = pk)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class MedicalHistoryUpdateView(View):
    template_name = 'dietplan/patient_history_update.html'
    def get(self, request, pk = None ):
        history = MedicalHistory.objects.get(id=pk)
        print(history,pk)
        form = MedicalHistoryForm(request.GET or None,instance=history)
        print(form)
        try:
            history = MedicalHistory.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'history' : history
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        history = MedicalHistory.objects.get(pk = pk)
        form = MedicalHistoryForm(request.POST or None, instance=history)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': history.patient.id}))

class MedicalHistoryDeleteView(DeleteView):
    model = MedicalHistory
    template_name = 'dietplan/delete_MedicalHistory.html'
    fields = ('__all__')

    def get_success_url(self):
        return redirect(reverse('patient-profile', kwargs={'pk':self.object.patient.id}))
# Create Medication List
class MedicationListCreateView(CreateView):
    template_name = 'dietplan/patient_medication_list.html'

    def get(self, request, pk = None ):
        form = MedicationListForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = MedicationListForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))
    
class MedicationListUpdateView(View):
    template_name = 'dietplan/patient_list_update.html'
    def get(self, request, pk = None ):
        medicationList = MedicationList.objects.get(id=pk)
        print(medicationList,pk)
        form = MedicationListForm(request.GET or None,instance=medicationList)
        print(form)
        try:
            medicationList = MedicationList.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'medicationList' : medicationList
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        medicationList = MedicationList.objects.get(pk = pk)
        form = MedicationListForm(request.POST or None, instance=medicationList)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': medicationList.patient.id}))

class MedicationListDeleteView(DeleteView):
    model = MedicationList
    template_name = 'dietplan/delete_MedicationList.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})


# Patient Profile
class PatientProfileView(View):
    """
    Detail view to handle paitent profile page of particular patient
    """
    template_name = 'dietplan/patient_profile_view.html'

    def get(self, request, pk):
        patient = Patient.objects.get(id=pk)
        patient_details = Patient.objects.filter(id=pk).all()
        issue_details = Issues.objects.filter(patient= patient).all()
        medical_history = MedicalHistory.objects.filter(patient= patient).all()
        medication_list = MedicationList.objects.filter(patient= patient).all()
        fat_scan = FatScan.objects.filter(patient= patient).all()
        water_intake = WaterIntake.objects.filter(patient= patient).all()
        food_diary = FoodDiary.objects.filter(patient= patient).all()
        menstrual_cycle = MenstrualCycle.objects.filter(patient= patient).all()
        blood_pressure = BloodPressure.objects.filter(patient= patient).all()
        alcohol = Alcohol.objects.filter(patient= patient).all()
        stool = Stool.objects.filter(patient= patient).all()
        stool_colour = StoolColour.objects.filter(patient= patient).all()
        stool_clearance = StoolClearance.objects.filter(patient= patient).all()
        fasting = Fasting.objects.filter(patient=patient).all()
        like = Like.objects.filter(patient=patient).all()
        dislike = Dislike.objects.filter(patient=patient).all()
        family_history={}
        family_history["father"] = FamilyHistory.objects.filter(patient=patient,side="father")
        family_history["mother"] = FamilyHistory.objects.filter(patient=patient,side="mother")
        personality_test={}
        personality_test["1"]={"option1":0,"option2":0,"option3":0}
        personality_test["2"]={"option1":0,"option2":0,"option3":0}
        personality_test["3"]={"option1":0,"option2":0,"option3":0}
        personality_test["total"]={"option1":0,"option2":0,"option3":0}
        for i in PersonalityAnswers.objects.filter(patient=patient):
            personality_test[i.question.part]["option1"]+=i.option1
            personality_test[i.question.part]["option2"]+=i.option2
            personality_test[i.question.part]["option3"]+=i.option3
            personality_test["total"]["option1"]+=i.option1
            personality_test["total"]["option2"]+=i.option2
            personality_test["total"]["option3"]+=i.option3
            # print(i.question.part,i.option1,i.option2,i.option3)
        # print(personality_test)
        context={
            'stool_clearance' : stool_clearance,
            'stool_colour' : stool_colour,
            'stool':stool,
            'alcohol' : alcohol,
            'blood_pressure' : blood_pressure,
            'food_diary' : food_diary,
            'water_intake' : water_intake,
            'fat_scan' :fat_scan,
            'medication_list' : medication_list,
            'medical_history' : medical_history,
            'patient_details' : patient_details,
            'issue_details' : issue_details,
            'family_history' : family_history,
            'personality_test':personality_test,
            'patient' : patient,
            'fasting':fasting,
            'like':like,
            'dislike':dislike,
            }
        try :
            gender = 'female'
            print(Patient.objects.filter(sex=gender).get(id=pk))
            context['menstrual_cycle'] = menstrual_cycle
        except Exception as e:
            print(e) 

        # print(context)
        return render(request, self.template_name, context )

#Family History
class FamilyHistoryView(View):
    template_name = 'dietplan/family_history.html'

    def get(self, request, pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        disease_list = Disease.objects.all()
        old_diseases={}
        old_diseases["father"]=[i.disease.name for i in FamilyHistory.objects.filter(patient=patient,side="father")]
        old_diseases["mother"]=[i.disease.name for i in FamilyHistory.objects.filter(patient=patient,side="mother")]
        print(old_diseases)
        context = {
            'patient' : patient,
            'disease_list' : disease_list,
            'old_diseases' : old_diseases
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        print(request.POST)
        print(request.POST.getlist('father'))
        father_diseases = [Disease.objects.filter(name=i)[0] for i in request.POST.getlist('father')]
        mother_diseases = [Disease.objects.filter(name=i)[0] for i in request.POST.getlist('mother')]
        old_diseases=FamilyHistory.objects.filter(patient=patient)
        print("++++"+str(old_diseases))

        for i in old_diseases:
            if i not in father_diseases and i not in mother_diseases:
                i.delete()
        for i in father_diseases:
            x,created=FamilyHistory.objects.get_or_create(patient=patient,disease=i,side="father")
            x.save()
            print("****"+str(x))
        for i in mother_diseases:
            x,created=FamilyHistory.objects.get_or_create(patient=patient,disease=i,side="mother")
            x.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

# Personality Test
class PersonalityTestView(View):
    template_name = 'dietplan/PersonalityTest.html'

    def get(self, request, pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        questions={}
        questions['1'] = PersonalityQuestion.objects.filter(part="1")
        questions['2'] = PersonalityQuestion.objects.filter(part="2")
        questions['3'] = PersonalityQuestion.objects.filter(part="3")
        old_answers = {i.question.observation:i for i in PersonalityAnswers.objects.filter(patient=patient)}
        print("old answer",old_answers)
        print("question",questions)
        context = {
            'patient' : patient,
            'questions':questions,
            'old_answers':old_answers
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        print(request.POST)
        old_answers = PersonalityAnswers.objects.filter(patient=patient)
        new_answers = {}
        for i in request.POST:
            if i=="csrfmiddlewaretoken":
                continue
            new_answers[i]=request.POST.getlist(i)

        for i in old_answers:
            if i.question.observation not in new_answers.keys():
                print(i)
                i.delete()

        for i in new_answers:
            try:
                answer,c=PersonalityAnswers.objects.get_or_create(patient=patient,question=PersonalityQuestion.objects.filter(observation=i)[0])
                print(new_answers[i])
                if('1' in new_answers[i]):
                    answer.option1=1
                else:
                    answer.option1=0
                if('2' in new_answers[i]):
                    answer.option2=1
                else:
                    answer.option2=0
                if('3' in new_answers[i]):
                    answer.option3=1
                else:
                    answer.option3=0
                answer.save()
            except Exception as e:
                print(e)
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class SymptomsFormView(View):
    template_name = 'dietplan/symptomsform.html'

    def get(self, request, pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        symptoms={}
        all_symptoms=Symptom.objects.all()
        for i in all_symptoms:
            try:
                symptoms[i.category][i.part].append(i)
            except:
                try:
                    symptoms[i.category][i.part]=[i]
                except:
                    symptoms[i.category]={i.part:[i]}
        old_symptoms={"a":{},"b":{},"c":{}}
        for i in PatientSymptom.objects.filter(patient=patient):
            try:
                old_symptoms[i.symptom.part][i.symptom.category].append(i.symptom)
            except:
                old_symptoms[i.symptom.part][i.symptom.category]=[i.symptom]
        print(old_symptoms)
        context = {
            'patient' : patient,
            'symptoms':symptoms,
            'old_symptoms':old_symptoms

        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        temp=request.POST.getlist("symptom")
        new_symptoms=[]
        for i in temp:
            x=i.split(",")
            try:
                y=Symptom.objects.filter(category=SymptomCategory.objects.filter(category=x[0])[0],symptom=x[1],part=x[2])
                new_symptoms.append(y[0])
            except Exception as e:
                print("error symptom",e)

        old_symptoms=PatientSymptom.objects.filter(patient=patient)

        for i in old_symptoms:
            if i.symptom not in new_symptoms:
                i.delete()
        old_symptoms_list=[j.symptom for j in old_symptoms]
        for i in new_symptoms:
            if i not in old_symptoms_list:
                obj=PatientSymptom.objects.create(patient=patient,symptom=i)
                obj.save()

        print(new_symptoms)
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))


class MedicalConditionsView(View):
    template_name = 'dietplan/medical_condition.html'

    def get(self, request, pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        medical_condition={}
        all_medical_condition=MedicalConditions.objects.all()
        for i in all_medical_condition:
            try:
                medical_condition[i.category][i.part].append(i)
            except:
                try:
                    medical_condition[i.category][i.part]=[i]
                except:
                    medical_condition[i.category]={i.part:[i]}
        old_medical_condition={"a":{},"b":{},"c":{}}
        for i in PatientMedicalConditions.objects.filter(patient=patient):
            try:
                old_medical_condition[i.medical_condition.part][i.medical_condition.category].append(i.medical_condition)
            except:
                old_medical_condition[i.medical_condition.part][i.medical_condition.category]=[i.medical_condition]
        print(old_medical_condition)
        context = {
            'patient' : patient,
            'medical_condition':medical_condition,
            'old_medical_condition':old_medical_condition

        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        temp=request.POST.getlist("medical_condition")
        new_medical_condition=[]
        for i in temp:
            x=i.split(",")
            try:
                y=MedicalConditions.objects.filter(category=MedicalConditionsCategory.objects.filter(category=x[0])[0],medical_condition=x[1],part=x[2])
                new_medical_condition.append(y[0])
            except Exception as e:
                print("error medical_condition",e)

        old_medical_condition=PatientMedicalConditions.objects.filter(patient=patient)

        for i in old_medical_condition:
            if i.medical_condition not in new_medical_condition:
                i.delete()
        old_medical_condition_list=[j.medical_condition for j in old_medical_condition]
        for i in new_medical_condition:
            if i not in old_medical_condition_list:
                obj=PatientMedicalConditions.objects.create(patient=patient,medical_condition=i)
                obj.save()

        print(new_medical_condition)
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class FatScanCreateView(CreateView):
    template_name = 'dietplan/patient_fat_scan.html'

    def get(self, request, pk = None ):
        form = FatScanForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = FatScanForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class FatScanUpdateView(View):
    template_name = 'dietplan/patient_fat_update.html'
    def get(self, request, pk = None ):
        fatscan = FatScan.objects.get(id=pk)
        print(fatscan,pk)
        form = FatScanForm(request.GET or None,instance=fatscan)
        print(form)
        try:
            fatscan = FatScan.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'fatscan' : fatscan
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        fatscan = FatScan.objects.get(pk = pk)
        form = FatScanForm(request.POST or None, instance=fatscan)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': fatscan.patient.id}))

class FatScanDeleteView(DeleteView):
    model = FatScan
    template_name = 'dietplan/delete_fatscan.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})



class WaterIntakeCreateView(CreateView):
    template_name = 'dietplan/patient_water_intake.html'

    def get(self, request, pk = None ):
        form = WaterIntakeForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = WaterIntakeForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class WaterIntakeUpdateView(View):
    template_name = 'dietplan/patient_water_update.html'
    def get(self, request, pk = None ):
        waterintake = WaterIntake.objects.get(id=pk)
        print(waterintake,pk)
        form = WaterIntakeForm(request.GET or None,instance=waterintake)
        print(form)
        try:
            waterintake = WaterIntake.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'waterintake' : waterintake
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        waterintake = WaterIntake.objects.get(pk = pk)
        form = WaterIntakeForm(request.POST or None, instance=waterintake)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': waterintake.patient.id}))

class WaterIntakeDeleteView(DeleteView):
    model = WaterIntake
    template_name = 'dietplan/delete_WaterIntake.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})

class FoodDiaryCreateView(CreateView):
    template_name = 'dietplan/patient_food_diary.html'

    def get(self, request, pk = None ):
        form = FoodDiaryForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = FoodDiaryForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))    

class FoodDiaryUpdateView(View):
    template_name = 'dietplan/patient_food_update.html'
    def get(self, request, pk = None ):
        fooddiary = FoodDiary.objects.get(id=pk)
        print(FoodDiary,pk)
        form = FoodDiaryForm(request.GET or None,instance=fooddiary)
        print(form)
        try:
            fooddiary = FoodDiary.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'fooddiary' : fooddiary
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        fooddiary = FoodDiary.objects.get(pk = pk)
        form = FoodDiaryForm(request.POST or None, instance=fooddiary)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': fooddiary.patient.id}))

class FoodDiaryDeleteView(DeleteView):
    model = FoodDiary
    template_name = 'dietplan/delete_FoodDiary.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})

class BloodPressureCreateView(CreateView):
    template_name = 'dietplan/patient_blood_pressure.html'

    def get(self, request, pk = None ):
        form = BloodPressureForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = BloodPressureForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))   

class BloodPressureUpdateView(View):
    template_name = 'dietplan/patient_bloodpressure_update.html'
    def get(self, request, pk = None ):
        bloodpressure = BloodPressure.objects.get(id=pk)
        print(bloodpressure,pk)
        form = BloodPressureForm(request.GET or None,instance=bloodpressure)
        print(form)
        try:
            bloodpressure = BloodPressure.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'bloodpressure' : bloodpressure
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        bloodpressure = BloodPressure.objects.get(pk = pk)
        form = BloodPressureForm(request.POST or None, instance=bloodpressure)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': bloodpressure.patient.id}))

class BloodPressureDeleteView(DeleteView):
    model = BloodPressure
    template_name = 'dietplan/delete_BloodPressure.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})

class MenstrualCycleCreateView(CreateView):
    template_name = 'dietplan/patient_menstrual_cycle.html'

    def get(self, request, pk = None ):
        form = MenstrualCycleForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = MenstrualCycleForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))  

class MenstrualCycleUpdateView(View):
    template_name = 'dietplan/patient_menstrualcycle_update.html'
    def get(self, request, pk = None ):
        menstrualcycle = MenstrualCycle.objects.get(id=pk)
        print(menstrualcycle,pk)
        form = MenstrualCycleForm(request.GET or None,instance=menstrualcycle)
        print(form)
        try:
            menstrualcycle = MenstrualCycle.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'menstrualcycle' : menstrualcycle
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        menstrualcycle = MenstrualCycle.objects.get(pk = pk)
        form = MenstrualCycleForm(request.POST or None, instance=menstrualcycle)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': menstrualcycle.patient.id}))

class MenstrualCycleDeleteView(DeleteView):
    model = MenstrualCycle
    template_name = 'dietplan/delete_MenstrualCycle.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})


class AlcoholCreateView(CreateView):
    template_name = 'dietplan/patient_alcohol.html'

    def get(self, request, pk = None ):
        form = AlcoholForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = AlcoholForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))  

class AlcoholUpdateView(View):
    template_name = 'dietplan/patient_alcohol_update.html'
    def get(self, request, pk = None ):
        alcohol = Alcohol.objects.get(id=pk)
        print(alcohol,pk)
        form = AlcoholForm(request.GET or None,instance=alcohol)
        print(form)
        try:
            alcohol = Alcohol.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'alcohol' : alcohol
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        alcohol = Alcohol.objects.get(pk = pk)
        form = AlcoholForm(request.POST or None, instance=alcohol)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': alcohol.patient.id}))

class AlcoholDeleteView(DeleteView):
    model = Alcohol
    template_name = 'dietplan/delete_Alcohol.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})


class StoolCreateView(View):
    template_name = 'dietplan/patient_stool.html'

    def get(self, request, pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        stooltype_list = StoolType.objects.all()
        print('///////'+str(stooltype_list))
        old_diseases={}
        old_diseases=[i.stool_type.name for i in Stool.objects.filter(patient=patient)]
        print('*******'+str(old_diseases))
        context = {
            'patient' : patient,
            'stooltype_list' : stooltype_list,
            'old_diseases' : old_diseases
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        print(request.POST)
        old_diseases=Stool.objects.filter(patient=patient)
        stool_save = [StoolType.objects.filter(name=i)[0] for i in request.POST.getlist('stool_type')]
        print("++++"+str(old_diseases)+'-----'+str(stool_save))

        for i in old_diseases:
            if i not in stool_save:
                i.delete()
        for i in stool_save:
            print(i)
            x=Stool.objects.create(patient=patient,stool_type=i)
            print("****"+str(x))
            x.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))


class StoolColourCreateView(View):
    template_name = 'dietplan/patient_stool_colour.html'

    def get(self, request, pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        stool_color_type_list = StoolColourType.objects.all()
        print('///////'+str(stool_color_type_list))
        old_diseases={}
        old_diseases=[i.stool_colour.type for i in StoolColour.objects.filter(patient=patient)]
        print('*******'+str(old_diseases))
        context = {
            'patient' : patient,
            'stool_color_type_list' : stool_color_type_list,
            'old_diseases' : old_diseases
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
            print(pk)
        print(request.POST)
        old_diseases=StoolColour.objects.filter(patient=patient)
        stool_colour_save = [StoolColourType.objects.filter(type=i)[0] for i in request.POST.getlist('stool_colour')]
        print("++++"+str(old_diseases)+'-----'+str(stool_colour_save))

        for i in old_diseases:
            if i not in stool_colour_save:
                i.delete()
        for i in stool_colour_save:
            print(i)
            x=StoolColour.objects.create(patient=patient,stool_colour=i)
            print("****"+str(x))
            x.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class StoolClearanceCreateView(CreateView):
    template_name = 'dietplan/patient_stool_clearance.html'

    def get(self, request, pk = None ):
        form = StoolClearanceForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = StoolClearanceForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class StoolClearanceUpdateView(View):
    template_name = 'dietplan/patient_stoolclearance_update.html'
    def get(self, request, pk = None ):
        stoolclearance = StoolClearance.objects.get(id=pk)
        print(stoolclearance,pk)
        form = StoolClearanceForm(request.GET or None,instance=stoolclearance)
        print(form)
        try:
            stoolclearance = StoolClearance.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'stoolclearance' : stoolclearance
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        stoolclearance = StoolClearance.objects.get(pk = pk)
        form = StoolClearanceForm(request.POST or None, instance=stoolclearance)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': stoolclearance.patient.id}))

class StoolClearanceDeleteView(DeleteView):
    model = StoolClearance
    template_name = 'dietplan/delete_StoolClearance.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})

class fastingCreateView(CreateView):
    template_name = 'dietplan/patient_fasting.html'

    def get(self, request, pk = None ):
        form = FastingForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = FastingForm(request.POST , request.FILES)

        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.patient = patient
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class fastingUpdateView(View):
    template_name = 'dietplan/patient_fasting_update.html'
    def get(self, request, pk = None ):
        fasting = Fasting.objects.get(id=pk)
        print(fasting,pk)
        form = FastingForm(request.GET or None,instance=fasting)
        print(form)
        try:
            fasting = Fasting.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'fasting' : fasting
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        fasting = Fasting.objects.get(pk = pk)
        form = FastingForm(request.POST or None, instance=fasting)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': fasting.patient.id}))

class fastingDeleteView(DeleteView):
    model = Fasting
    template_name = 'dietplan/delete_fasting.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})

class likeCreateView(CreateView):
    template_name = 'dietplan/patient_like.html'

    def get(self, request, pk = None ):
    
        try:
            patient = Patient.objects.get(pk = pk)
            print(patient)
            print(request.GET)
            list1 = list(request.GET)
            try:
                like1 = Like.objects.filter(patient=patient)
                for i in range(len(list1)-1):
                    likes = Like()
                    likes.patient = patient
                    print(request.GET[f'likes[{i}][like]']) 
                    if not Like.objects.filter(patient=patient,Like=request.GET[f'likes[{i}][like]']).exists() :
                        if request.GET[f'likes[{i}][like]'] != '':
                            likes.Like = request.GET[f'likes[{i}][like]']
                            likes.save()
            except Exception as e:
                pass
            try:
                for i in range(len(list1)-1):
                    dislikes = Dislike()
                    dislikes.patient = patient
                    print(request.GET[f'dislikes[{i}][dislike]']) 
                    if not Dislike.objects.filter(patient=patient,DisLike=request.GET[f'dislikes[{i}][dislike]']).exists() :
                        if request.GET[f'dislikes[{i}][dislike]'] != '':
                            dislikes.DisLike = request.GET[f'dislikes[{i}][dislike]']
                            dislikes.save()
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)
            patient = pk
        context = {
            'like' : like1,
            'patient' : patient,
            }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class likeUpdateView(View):
    template_name = 'dietplan/patient_like_update.html'
    def get(self, request, pk = None ):
        like = Like.objects.get(id=pk)
        print(like,pk)
        form = LikeForm(request.GET or None,instance=like)
        print(form)
        try:
            like = Like.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
        
        context = {
            'form' : form,
            'like' : like
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        like = Like.objects.get(pk = pk)
        form = LikeForm(request.POST or None, instance=like)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': like.patient.id}))

class likeDeleteView(DeleteView):
    model = Like
    template_name = 'dietplan/delete_like.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})

class dislikeUpdateView(View):
    template_name = 'dietplan/patient_dislike_update.html'
    def get(self, request, pk = None ):
        dislike = Dislike.objects.get(id=pk)
        print(dislike,pk)
        form = DislikeForm(request.GET or None,instance=dislike)
        print(form)
        try:
            dislike = Dislike.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
        
        context = {
            'form' : form,
            'dislike' : dislike
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        dislike = Dislike.objects.get(pk = pk)
        form = DislikeForm(request.POST or None, instance=dislike)
        print(form)
        if form.is_valid():
            document_object = form.save(commit=False)
            document_object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': dislike.patient.id}))

class dislikeDeleteView(DeleteView):
    model = Dislike
    template_name = 'dietplan/delete_dislike.html'
    fields = ('__all__')

    def get_success_url(self):
        return reverse('patient-profile', kwargs={'pk':self.object.patient.id})

class AppointmentProfileView(View):
    """
    Detail view to handle paitent profile page of particular patient
    """
    template_name = 'dietplan/patientappointment_profile.html'

    def get(self, request, pk):
        patient = Patient.objects.get(id=pk)
        patient_details = Patient.objects.filter(id=pk).all()
        issue_details = Issues.objects.filter(patient= patient).all()
        medical_history = MedicalHistory.objects.filter(patient= patient).all()
        medication_list = MedicationList.objects.filter(patient= patient).all()
        fat_scan = FatScan.objects.filter(patient= patient).all()
        water_intake = WaterIntake.objects.filter(patient= patient).all()
        food_diary = FoodDiary.objects.filter(patient= patient).all()
        menstrual_cycle = MenstrualCycle.objects.filter(patient= patient).all()
        blood_pressure = BloodPressure.objects.filter(patient= patient).all()
        alcohol = Alcohol.objects.filter(patient= patient).all()
        stool = Stool.objects.filter(patient= patient).all()
        stool_colour = StoolColour.objects.filter(patient= patient).all()
        stool_clearance = StoolClearance.objects.filter(patient= patient).all()
        fasting = Fasting.objects.filter(patient=patient).all()
        like = Like.objects.filter(patient=patient).all()
        dislike = Dislike.objects.filter(patient=patient).all()
        family_history={}
        family_history["father"] = FamilyHistory.objects.filter(patient=patient,side="father")
        family_history["mother"] = FamilyHistory.objects.filter(patient=patient,side="mother")
        personality_test={}
        personality_test["1"]={"option1":0,"option2":0,"option3":0}
        personality_test["2"]={"option1":0,"option2":0,"option3":0}
        personality_test["3"]={"option1":0,"option2":0,"option3":0}
        personality_test["total"]={"option1":0,"option2":0,"option3":0}
        for i in PersonalityAnswers.objects.filter(patient=patient):
            personality_test[i.question.part]["option1"]+=i.option1
            personality_test[i.question.part]["option2"]+=i.option2
            personality_test[i.question.part]["option3"]+=i.option3
            personality_test["total"]["option1"]+=i.option1
            personality_test["total"]["option2"]+=i.option2
            personality_test["total"]["option3"]+=i.option3
            # print(i.question.part,i.option1,i.option2,i.option3)
        # print(personality_test)
        context={
            'stool_clearance' : stool_clearance,
            'stool_colour' : stool_colour,
            'stool':stool,
            'alcohol' : alcohol,
            'blood_pressure' : blood_pressure,
            'food_diary' : food_diary,
            'water_intake' : water_intake,
            'fat_scan' :fat_scan,
            'medication_list' : medication_list,
            'medical_history' : medical_history,
            'patient_details' : patient_details,
            'issue_details' : issue_details,
            'family_history' : family_history,
            'personality_test':personality_test,
            'patient' : patient,
            'fasting':fasting,
            'like':like,
            'dislike':dislike,
            }
        try :
            gender = 'female'
            print(Patient.objects.filter(sex=gender).get(id=pk))
            context['menstrual_cycle'] = menstrual_cycle
        except Exception as e:
            print(e) 

        # print(context)
        return render(request, self.template_name, context )        

class CusineCreateView(CreateView):
    template_name = 'dietplan/cusine_create.html'

    def get(self, request, pk = None ):
        form = CusineForm()
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk

        context = {
            'form' : form,
            'patient' : patient
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        form = CusineForm(request.POST , request.FILES)

        if form.is_valid():
            object = form.save(commit=False)
            object.patient = patient
            object.save()
        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))

class BodyMeasurementCreateView(View):
    template_name = 'dietplan/BodyMeasurement_create.html'

    def get(self, request, pk = None ):
        try:
            patient = Patient.objects.get(pk = pk)

        except Exception as e:
            print(e)
            patient = pk
        try:
            x=BodyMeasurement.objects.filter(patient=patient)[0]
        except:
            x=BodyMeasurement.objects.create(patient=patient)
        context = {
            'patient' : patient,
            'old_measurements':x
        }
        return render(request,self.template_name,context)

    def post(self,request,pk = None ):
        patient = Patient.objects.get(pk = pk)
        try:
            x=BodyMeasurement.objects.filter(patient=patient)[0]
        except:
            x=BodyMeasurement.objects.create(patient=patient)
        x.height = request.POST['height'] if request.POST['height']!=None else ""
        x.neck = request.POST['neck'] if request.POST['neck']!=None else ""
        x.shoulder = request.POST['shoulder'] if request.POST['shoulder']!=None else ""
        x.chest = request.POST['chest'] if request.POST['chest']!=None else ""
        x.waist = request.POST['waist'] if request.POST['waist']!=None else ""
        x.pelvis = request.POST['pelvis'] if request.POST['pelvis']!=None else ""
        x.hip = request.POST['hip'] if request.POST['hip']!=None else ""
        x.thigh = request.POST['thigh'] if request.POST['thigh']!=None else ""
        x.calf = request.POST['calf'] if request.POST['calf']!=None else ""
        x.arm = request.POST['arm'] if request.POST['arm']!=None else ""
        x.wrist = request.POST['wrist'] if request.POST['wrist']!=None else ""
        x.shape = request.POST['shape'] if request.POST['shape']!=None else "Apple"
        x.ratio = request.POST['ratio'] if request.POST['ratio']!=None else ""
        x.ideal_waist = request.POST['ideal_waist'] if request.POST['neck']!=None else ""
        x.save()

        return redirect(reverse('patient-profile', kwargs = {'pk': patient.id}))