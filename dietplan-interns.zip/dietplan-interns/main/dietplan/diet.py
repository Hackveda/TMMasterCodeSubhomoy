import os
import docx2txt
import json
import re

dir1 = os.getcwd()
dir2 = str(dir1) +'/KOLKATTA-BENGALI FOLDER (English)'
dir_arr = os.listdir(dir2) 
#print(dir_arr)
i=1
dict1 = {}
list1=[]
dict1['/KOLKATTA-BENGALI FOLDER (English)'] = list1
for doc in dir_arr:
    doc1 = str(dir1) +'/KOLKATTA-BENGALI FOLDER (English)/' + str(doc)
    # print(doc1)
    my_text = docx2txt.process(doc1)
    # print(my_text)
    strings = re.findall(r'\d[.]\s[A-Z]+', my_text)
    strings_1 = re.findall(r'\d{1,4}[a-g]\b \b[A-Z]+', my_text)
    print(strings_1)
    for string in strings:
        dict2 = {}
        dict2['category_no']=i
        dict2['category_name']=doc
        string_num, string_name = string.split('.\t') 
        # print(string_num, string_name)
        dict2['SubCategory_no'] = string_num
        dict2['SubCategory_name'] = string_name
        dict1['/KOLKATTA-BENGALI FOLDER (English)'].append(dict2)
    i+=1

    
# print(dict1)
with open('category.json', 'w') as outfile:
    json.dump(dict1, outfile,ensure_ascii=False, indent=2)